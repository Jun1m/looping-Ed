<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Looping de Nomes</title>
</head>
<body style="background-color: black; color: green; font-family: Courier New, monospace;">
    <h2>Informe seu nome:</h2>
    <form method="POST">
        <label>Informe seu nome:</label>
        <input type="text" name="nome">
        <button type="submit" name="exibir">Exibir</button>
    </form>
    <?php
    if(isset($_POST['exibir'])) {
        $nome = $_POST['nome'];
        if (!empty($nome)) {
            echo "<h3>Nomes inseridos:</h3>";
            for ($i = 1; $i <= 10; $i++) {
                echo "$i. $nome<br>";
            }
        } else {
            echo "<p>Preencha o campo com seu nome.</p>";
        }
    }
    ?>
</body>
</html>
